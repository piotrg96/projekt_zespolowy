import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { Navbar } from './../_components';
import { userActions } from '../_actions';

class AdvertisementCreate extends React.Component {

    constructor(props)
    {
        super(props);
        this.state = {
            
            advertisement:{
                title: '',
                description: '',
                price: '',
                yardage: '',
                phone: '',
                cityName: '',
                provinceName: '',
                categoryName: '',
            },

            categories: [{}],
            cities: [{}],
            provinces: [{}],
        
            submitted:false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount()
    {
        fetch(`http://localhost:49396/api/CategoryModels`)
        .then(res => res.json())
        .then(data => this.setState({
            categories: data
        })),

        fetch(`http://localhost:49396/api/CityModels`)
        .then(res => res.json())
        .then(data => this.setState({
            cities: data
        })),

        fetch(`http://localhost:49396/api/ProvinceModels`)
        .then(res => res.json())
        .then(data => this.setState({
            provinces: data
        }))

    }

    
    handleChange(e) 
    {
        const { name, value } = e.target;
        const { advertisement } = this.state;
        this.setState({
            advertisement: {
                ...advertisement,
                [name]: value
            }
        });
    }

    handleSubmit(e) 
    {
        e.preventDefault();

        this.setState({ submitted: true });
        const { advertisement } = this.state;
        const { dispatch } = this.props; 
        if(advertisement.price > 0 && advertisement.title != null && advertisement.description != null)
        {
             dispatch(userActions.sendAdvertisement(advertisement));
        }
    }


    render() {
    
    let users = this.props.users.items || {}
    const { advertisement ,cities, provinces, categories, submitted} = this.state;

    return (
        <div>
            {console.log(advertisement)}
            <Navbar concreteUser={users}/>
            <form className="form" onSubmit={this.handleSubmit}>
            <div className="row my-5 px-3">
                
                <div className={"col-md-6 border border-success" + (submitted && !(advertisement.title) ? ' has-error ' : '') }>

                    <div className="h2 my-3 border border-success">Title:
                        <input type="text" className="ml-2"name="title" value={advertisement.title} onChange={this.handleChange}/>
                        {
                            submitted && !advertisement.title &&
                            <div className="text-danger">Title is required</div>
                        }
                    </div>

                    <div className="row">
                        <div className={"col-md-6 h5 border border-success my-3" + (submitted && !(advertisement.categoryName) ? ' has-error ' : '') }>Category:
                
                            <select className="ml-2">
                            <option></option>
                            {
                                categories.map((cat,i) => (
                                    <option key={i} name="categoryName" value={advertisement.categoryName} onChange={this.handleChange}>{cat.name}</option>  
                                ))
                            }
                            </select>

                         </div>

                        <div className={"col-md-6 h5 border border-success my-3" + (submitted && !(advertisement.yardage) ? ' has-error ' : '') }>Yardage:
                            <input type="number" className="ml-2" name="yardage" min="1" max="1000" value={advertisement.yardage} onChange={this.handleChange}/>
                            {
                            submitted && !advertisement.yardage &&
                            <div className="text-danger">Yardage is required</div>
                            }
                        </div>
                    </div>

                    <div className="row">
                        <div className={"col-md-6 h5 border border-success my-3 text-center" + (submitted && !(advertisement.provinceName) ? ' has-error ' : '') }>Province:
                
                            <select>
                            <option></option>
                            {
                                provinces.map((province,i) => (
                                    <option key={i}  name="provinceName" value={advertisement.provinceName} onChange={this.handleChange}>{province.provinceName}</option>  
                                ))
                            }
                            </select>

                         </div>
                        <div className={"col-md-6 h5 border border-success my-3 text-center" + (submitted && !(advertisement.cityName) ? ' has-error ' : '') }>City: 
                        
                        <select>
                            <option></option>
                            {
                                cities.map((city,i) => (
                                    <option key={i} name="cityName" value={advertisement.cityName} onChange={this.handleChange}>{city.cityName}</option>  
                                ))
                            }
                            </select>
                        </div>

                    </div>

                    <div className={"h5 text-center" + (submitted && !(advertisement.description) ? ' has-error ' : '') }>description: 
                            <textarea className="col-md-12 border border-success my-3 py-3" name="description" value={advertisement.description} onChange={this.handleChange} wrap="hard" maxLength="255" placeholder="max length 255 characterts"/>
                            {
                            submitted && !advertisement.description &&
                            <div className="text-danger">Description is required</div>
                            }
                    </div> 
                    <div className="row">
                        <div className={"col-md-6 h5 border border-success my-3" + (submitted && !(advertisement.price) ? ' has-error ' : '') }>Price: 
                            <input type="number" min="0" max="999999" name="price" value={advertisement.price} onChange={this.handleChange}/>
                            {
                            submitted && !advertisement.price &&
                            <div className="text-danger">Price is required</div>
                            }
                        </div>
                        <div className={"col-md-6 h5 border border-success my-3" + (submitted && !(advertisement.phone) ? ' has-error ' : '') }>Phone:
                            <input type="tel" name="phone" value={advertisement.phone} onChange={this.handleChange} pattern="[0-9]{9}" required/>
                            {
                            submitted && !advertisement.phone &&
                            <div className="text-danger">Phone is required</div>
                            }
                         </div>
                    </div>
                </div>
                <div className="col-md-6 border border-success">
                    <img className="img-fluid w-100 h-auto p-3" src="https://avatars0.githubusercontent.com/u/810438?v=4" />
                </div>
                
            </div>
            <button className="btn btn-primary mb-5">Submit</button>
            <Link to="/" className="btn btn-primary btn-block py-1 mb-3">Cancel</Link>
            </form>
        </div>
    );}
}

function mapStateToProps(state) {
    const { users, AdvertisementCreate} = state;
    return {
        users,
        AdvertisementCreate
    };
}

const connectedAdvertisementCreate = connect(mapStateToProps)(AdvertisementCreate);
export { connectedAdvertisementCreate as AdvertisementCreate };
